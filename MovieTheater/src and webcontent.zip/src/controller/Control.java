package controller;
import database.Database;
import model.Movie;
import model.User;

public class Control {
	public static boolean isValid(String un, String psw) {
		if(Database.isValid(un, psw)) {
			
		
			return true;
		}
		else
			return false;
	}
	public static int addNewuser(String un, String psw,String fn,String ln,String email, String bday,String phone) {
		User u = new User(un,psw,fn,ln,email,bday,phone);
		if (Database.addUser(u) == 1)  //User already exists
			return 1;
		else //User added successfully
			return 0;	
	}
	public static int addNewMovie(String mn, String gnr,String drc, int year,String act,String rvw, String trl, String pic, int len) {
		Movie m = new Movie(0,mn,gnr,drc,year,act,rvw,trl,pic,len);
		if (Database.addNewMovie(m) == 1)  //Movie already exists
			return 1;
		else //Movie added successfully
			return 0;
	}
	public static User setUser(String userName){
		User u = Database.setUser(userName);
		return u;	
	}
	public static void updateInfo(String userName, String newPsw) {
		Database.updateInfo(userName, newPsw);
	}
	public static int numOfMovies() {
		return Database.numOfMovies();
	}
	public static Movie[] getRecent() {
		Movie recent[] = Database.getRecent();
		return recent;
	}
}
