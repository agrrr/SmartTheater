package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class Movie {
	public int id;
	private String name;
	private String genre;
	private String directors;
	private int year;
	private String actors;
	private String review;
	private String trailer;
	private String picture;
	private int length;
	private Type gen;
	public int weight=0;
	Vector <Screening> screenings;
	
	public Movie(int id, String name, String genre, String directors, int year, String actors, String review, String trailer, String picture, int length) {
		this.id=id;
		this.name = name;
		this.genre = genre;
		this.directors = directors;
		this.year = year;
		this.actors = actors;
		this.review = review;
		this.trailer = trailer;
		this.picture = picture;
		this.length = length;
		this.screenings= new Vector<Screening>(1,2);
	}
	 public Movie(ResultSet res)
	  {
		  try {
			id = res.getInt("id");
			name = res.getString("name");
			genre= res.getString("genre");
			directors= res.getString("directors");
			year = res.getInt("year");
			actors = res.getString("actors");
			review = res.getString("review");
			trailer = res.getString("trailer");
			picture = res.getString("picture");
			
			this.screenings= new Vector<Screening>(1,2);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }
	/*public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public void setDirectors(int year) {
		this.year = year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public void setActors(String actors) {
		this.actors = actors;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public void setTrailer(String trailer) {
		this.trailer = trailer;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}*/

	public String getName() {
		return name;
	}
	public String getGenre() {
		return genre;
	}
	public String getDirectors() {
		return directors;
	}
	public int getYear() {
		return year;
	}
	public String getActors() {
		return actors;
	}
	public String getReview() {
		return review;
	}
	public String getTrailer() {
		return trailer;
	}
	public String getPicture() {
		return picture;
	}
	public int getLength() {
		return length;
	}
}
