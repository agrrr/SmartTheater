package model;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import database.Database;

public class Screening {
	public int movieId;
	public Movie movie;
	public String date;
	public String time;
	public int sold=0;
	public int allTickets=100;
	
	Screening(Movie movie,String date,String time){
		this.movie=movie;
		this.date=date;
		this.time = time;
		// we need to check that the date is ok, no overlap..
		// update the screening database..
		this.movie.screenings.addElement(this);
	}
	Screening(ResultSet res){
		try {
			date= res.getString("date");
			System.out.println("After date "+ date);
			time= res.getString("time");
			System.out.println("After time "+ time);
			sold = res.getInt("sold");
			System.out.println("After sold "+ sold);
		movieId =res.getInt("movieId");
		
		
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}
	public void sellTicket() {
		// we will add ticket at the ticket db
		// the history will be updated at the next sight in;
		sold++;
	}

}
