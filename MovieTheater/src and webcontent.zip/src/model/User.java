package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import database.Database;

public class User {
	public String userName;
	private String password;
	private String firstName;
	private String lastName;
	private String email;
	private String birthday;
	private String phone;
	
	public Vector <Movie> movie;
	public Vector <History> history;
	public Vector <Screening> screening;
	public Vector <Type> type;
	
	public User(String un, String psw,String fn,String ln,String mail, String bday,String p) {
		/*setUserName(un);
		setPassword(psw);
		setFirstName(fn);
		setLastName(ln);
		setEmail(email);
		setBirthday(bday);
		setPhone(phone);*/
		
		userName = un;
		password = psw;
		firstName =fn;
		lastName = ln;
		email = mail;
		birthday = bday;
		phone = p;
	}
	
	public void creatLocaldb() {
		ResultSet res;
		movie = new Vector<Movie>(1,4);
		screening = new Vector<Screening>(1,4);
	//**************************************************************
		res= Database.getMoviedb();/// building local movies db
		try {
		while(res.next()) {
			System.out.println(res.getString("name")+" inside while");
			movie.addElement (new Movie(res));

		}
		System.out.println(movie.elementAt(0).getName()+" element At ********");
	//******************creating Screening local db********
		res = Database.getScreeningdb();
		while(res.next()) {
			System.out.println(res.getString("date")+" screening inside while");
			screening.addElement(new Screening(res));
			screening.lastElement().movie=movie.elementAt(screening.lastElement().movieId-1);//connectivity
			System.out.println(screening.lastElement().movie.getName()+" screening**");
			screening.lastElement().movie.screenings.addElement(screening.lastElement());
		}
		System.out.println(movie.elementAt(0).getName()+" element At ********");
	}
		catch (SQLException e) {
			e.printStackTrace();
			}
		
	}
	public void creatPersonaldb() {
		ResultSet res;
		history = new Vector<History>(1,3);
		try {
	//************ creating historydb*********
		res = Database.getHistorydb();
		while(res.next()) {
			history.addElement(new History(res));
			history.lastElement().movie=movie.elementAt(history.lastElement().movieId-1);//connectivity
			System.out.println(history.lastElement().movie.getName()+" history**");
		}
	// now we need to run on the history and connect it to types...making weights
	// after connecting we want to remove history movies from moviedb
		
	//***notes:********now goint to the first part of the algo, at enother funt*****
	// part 1: now we want to run over all moviedb and connect them to the relevant types
		//	if manager we will take the types from the sqldb at this point,all other is the same
	// part 2: spread weights threw type vector
	// part 3(view): sort the movieVector/screeningVector by weight
	// part 4:show the results.
	}
		catch (SQLException e) {
			e.printStackTrace();
			}
		
	}
	/*public void setPassword(String psw) {
		password = psw;
	}
	public void setUserName(String un) {
		userName = un;
	}

	public void setFirstName(String fn) {
		firstName = fn;
	}
	public void setLastName(String ln) {
		lastName = ln;
	}
	public void setEmail(String mail) {
		email = mail;
	}
	public void setBirthday(String bday) {
		birthday = bday;
	}
	public void setPhone(String p) {
		phone  = p;
	}*/
	public String getUserName() {
		return userName;
	}
	public String getPassword() {
		return password;
	}
	public String getfirstName() {
		return firstName;
	}
	public String getlastName() {
		return lastName;
	}
	public String getEmail() {
		return email;
	}
	public String getPhone() {
		return phone;
	}
	public String getBirthday() {
		return birthday;
	}
}

