package view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SetScreening
 */
@WebServlet("/SetScreening")
public class SetScreening extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SetScreening() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String date = request.getParameter("date").toString();
        String time = request.getParameter("time").toString();
        String movieName = request.getParameter("movie").toString();
        System.out.println(date);
        System.out.println(time);
        System.out.println(movieName);
		String nextHtml = response.encodeRedirectURL("setscreening.jsp");
		response.sendRedirect(nextHtml);
        out.close();
	}

}
