package model;

public class Ticket {
public String id;
public String date;
public String movieId;
public String movieName;
public String genre;
public String directore;
}
